import { combineReducers } from 'redux';
import counterReducer1 from './counterReducer';

const counterApp = combineReducers({
  counterReducer1
})

export default counterApp
