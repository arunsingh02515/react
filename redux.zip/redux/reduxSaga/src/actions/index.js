import * as actionType from './ActionType';

export const ageUp = () => ({
  type: actionType.AGE_UP,
  payload: 2
});

export const ageDown = () => ({
  type: actionType.AGE_DOWN,
  payload: 1
});
