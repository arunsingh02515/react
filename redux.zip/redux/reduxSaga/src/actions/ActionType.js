
export const AGE_UP = 'AGE_UP';
export const AGE_DOWN = 'AGE_DOWN';






