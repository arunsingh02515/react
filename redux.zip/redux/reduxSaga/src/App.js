import React, { Component } from "react";
//import "./App.css";
import { connect } from "react-redux";
import {ageUp} from './actions';
import { bindActionCreators } from 'redux';
class App extends Component {
	
	
	
  render() {
    return (
      <div>
        <div>
          your age: <span>{this.props.age}</span>
        </div>

		<button className="button is-primary" onClick={(e) => {e.preventDefault();this.props.dispatch(ageUp())}}>Add</button>
      </div>
    );
  }
}
function mapDispatchToProps(dispatch) {
  return { actions: bindActionCreators(ageUp, dispatch) }
}
const mapStateToProps = state => {
  return {
    age: state.age
  };
};


export default connect(
  mapStateToProps
)(App);
