import "regenerator-runtime/runtime";
import { delay } from "redux-saga";
import { takeLatest, put } from "redux-saga/effects";

function* ageUpAsync() {
  //yield delay(4000);
  yield put({ type: "AGE_UP_ASYNC", value: 5 });
}

export function* watchAgeUp() {
	console.log("saga");
	
  yield takeLatest("AGE_UP", ageUpAsync);
}
