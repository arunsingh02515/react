import { combineReducers } from 'redux';
import counterReducer1 from './counterReducer';

const counterApp = combineReducers({
  countReduce:counterReducer1
})

export default counterApp
