import * as actionType from '../actions/ActionType';
const INITIAL_STATE = {
  data: 10
};
const counterReducer1 = (state = INITIAL_STATE, action) => {
  let data1;
  switch (action.type) {
    case actionType.ADD_COUNTER:
	     data1=state.data + action.payload;
	return { ...state, data: data1 }
      //return state + action.payload;
    case actionType.REMOVE_COUNTER:
	   data1= state.data - action.payload;
	 return { ...state, data: data1 }
      
    default:
      return state
  }
}

export default counterReducer1;
