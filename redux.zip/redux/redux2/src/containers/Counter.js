import React, { Component } from 'react';
import { connect } from 'react-redux';

class Counter extends Component {
  constructor(props){
    super(props);
  }
  render(){
    return (
      <div className="cotainer">
        <div className="notification">
          <h1>
          {this.props.text}
          </h1>
        </div>
    </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    text: state.countReduce.data
  }
}
export default connect(mapStateToProps)(Counter);
