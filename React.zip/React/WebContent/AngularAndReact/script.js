angular.module('myApp', [])
  .controller('myCtrl', function($scope) {
    $scope.myModel = {
      message: 'World'
    };
  })
  .directive('myMessage', function() {
    return {
      link: function(scope, element) {
        scope.$watch('myModel.message', function(newVal, oldVal) {
          //if(oldVal !== newVal) return;
          
          React.renderComponent(Hello({
            name: scope.myModel.message
          }), document.getElementById('example'));
        });
      }
    }
  })