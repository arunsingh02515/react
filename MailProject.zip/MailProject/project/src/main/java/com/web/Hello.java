package com.web;

public class Hello {
 
	public void dis() {
		System.out.println("Hello");
	}
}
