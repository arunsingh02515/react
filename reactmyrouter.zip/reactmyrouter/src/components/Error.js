import React from "react"

const Error=()=>{

    return(
        <div>
          Not Exist
            </div>
    )

};

export default Error;