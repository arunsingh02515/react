
import React, { Component } from 'react';
class HomeDetails extends Component{
  
  render() {
    return(
        <div>
          {this.props.homeProps}
            </div>
    )
  }

};

export default HomeDetails;