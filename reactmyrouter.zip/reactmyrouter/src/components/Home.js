import React, { Component } from 'react';
import HomeDetails from './HomeDetails';
class Home extends Component {
  constructor(props){
    super(props);
    this.state={"homeDetails":"hello this is my first"};
  }
  
  render() {
    return (
      
       <div><HomeDetails homeProps={this.state.homeDetails}></HomeDetails>
      </div>
    );
  }
}

export default Home;